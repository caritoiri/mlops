# components/train/train.py
import argparse, os, joblib, json, warnings
warnings.filterwarnings("ignore")
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression

import mlflow
import mlflow.sklearn

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--model_dir", type=str, required=True)
    parser.add_argument("--test_out", type=str, required=True)
    parser.add_argument("--register_name", type=str, default="")  # opcional: nombre en Registry
    args = parser.parse_args()

    os.makedirs(args.model_dir, exist_ok=True)
    os.makedirs(os.path.dirname(args.test_out), exist_ok=True)

    df = pd.read_csv(args.data)
    target_col = "Survived"
    assert target_col in df.columns, f"Column '{target_col}' not found in CSV."

    candidate_features = [
        c for c in df.columns if c not in [target_col, "PassengerId", "Name", "Ticket", "Cabin"]
    ]
    X = df[candidate_features]
    y = df[target_col]

    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = [c for c in X.columns if c not in num_cols]

    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, num_cols),
            ("cat", categorical_transformer, cat_cols),
        ],
        remainder="drop"
    )

    model = LogisticRegression(max_iter=1000)
    pipe = Pipeline(steps=[("prep", preprocessor), ("model", model)])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2,
        random_state=42,
        stratify=y if len(np.unique(y)) == 2 else None
    )

    # ===== MLflow tracking =====
    with mlflow.start_run(run_name="train"):
        # Parámetros “didácticos”
        mlflow.log_param("algorithm", "LogisticRegression")
        mlflow.log_param("max_iter", 1000)
        mlflow.log_param("n_features", X_train.shape[1])
        mlflow.log_param("n_train", X_train.shape[0])
        mlflow.log_param("n_test", X_test.shape[0])

        pipe.fit(X_train, y_train)

        # Guarda modelo para el paso "score"
        model_path = os.path.join(args.model_dir, "model.pkl")
        joblib.dump(pipe, model_path)

        # Loguea el modelo como artefacto MLflow
        mlflow.sklearn.log_model(pipe, artifact_path="model")

        # (Opcional) Registrar en el Model Registry del Workspace
        if args.register_name:
            mlflow.register_model(
                model_uri=f"runs:/{mlflow.active_run().info.run_id}/model",
                name=args.register_name
            )

    # Exporta el split de test para "score"
    test_df = X_test.copy()
    test_df[target_col] = y_test.values
    test_df.to_csv(args.test_out, index=False)

    print(f"Saved model to {model_path}")
    print(f"Saved test split to {args.test_out}")

if __name__ == "__main__":
    main()
